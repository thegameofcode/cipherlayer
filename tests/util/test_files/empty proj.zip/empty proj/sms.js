var config = JSON.parse(fs.readFileSync('config.json','utf8'));

function start(publicPort, privatePort, cbk){
    server = restify.createServer({
        name: 'test-server'
    });

    server.use(restify.bodyParser());

    server.listen(publicPort, function(){
        cbk();
    });
}

function stop(cbk){
    server.close(function(){
        cbk();
    });
}

module.exports = {
    start : start,
    stop : stop
};