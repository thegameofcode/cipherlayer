var spawn = require('child_process').spawn;
var net = require('net');
var fs = require('fs');
var config = JSON.parse(fs.readFileSync('config.json','utf8'));
var async = require('async');
var notifications = require('../notifications');

describe('proxy', function() {

    it('launchs', function (done) {
        var notifications;
        async.series([
            function (done) {
                notifications = spawn('node', ['main']);
                notifications.stdout.on('data', function (data) {
                    if (String(data).indexOf('listening on port') > -1) {
                        done();
                    }
                });
            },
            function (done) {
                var client = net.connect({port: config.public_port}, function () {
                    client.destroy();
                    notifications.kill('SIGTERM');
                    done();
                });
            }
        ], function () {
            done();
        });
    });
});