var assert = require('assert');

describe('SMS', function(){

    var sms = [
        {
            phone:'',
            text:''
        }
    ];

    it('send', function(done){
        done();
    });
});